package edu.iudigital.iudigitalradio.model

data class Station(
    val id: Int,
    val name: String,
    val genre: String,
    val streamUrl: String
)