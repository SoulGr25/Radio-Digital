package edu.iudigital.iudigitalradio.data

import edu.iudigital.iudigitalradio.model.Station

val stations = listOf(
    Station(1, "Radio Nacional de Colombia", "Cultura / Noticias", "https://radio3.rtvc.gov.co/radionacional.mp3"),
    Station(2, "Latina Estéreo", "Salsa", "https://stream.zeno.fm/f32630z85wtuv"),
    Station(3, "Blu Radio", "Noticias / Variada", "https://redirector.dps.live/blu/audio/icecast.audio"),
    Station(4, "Tropicana Bogotá", "Tropical", "https://prisa-cl.flumotion.com/prisa/tropicana_bogota.mp3"),
    Station(5, "La Mega", "Juvenil / Pop", "https://prisa-cl.flumotion.com/prisa/lamega_bogota.mp3"),
    Station(6, "Uniminuto Radio", "Universitaria", "https://radio.uniminuto.edu/stream")
)
